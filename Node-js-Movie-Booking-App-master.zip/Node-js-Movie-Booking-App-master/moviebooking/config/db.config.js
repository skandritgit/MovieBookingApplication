const DB_URL = `mongodb://localhost:27017/moviesdb`;

module.exports = DB_URL;
